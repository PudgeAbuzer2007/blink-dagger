from flask import Flask
from data import db_session
from data.users import User

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/blogs.db")
    user = User()
    user.surname = "Scott"
    user.name = "Ridley"
    user.age = 21
    user.position = 'captain'
    user.speciality = 'research engineer'
    user.address = 'module_1'
    user.email = "scott_chief@mars.org"
    db_sess = db_session.create_session()
    db_sess.add(user)
    db_sess.commit()

    user = User()
    user.surname = "Панфилов"
    user.name = "Иван"
    user.age = 16
    user.position = 'krutoi_paren'
    user.speciality = 'coder'
    user.address = 'module_2'
    user.email = "jaza_nashih@mars.org"
    db_sess = db_session.create_session()
    db_sess.add(user)
    db_sess.commit()

    user = User()
    user.surname = "Мордовский"
    user.name = "Семён"
    user.age = 15
    user.position = 'paren_pokruche'
    user.speciality = 'dota_player'
    user.address = 'module_3'
    user.email = "esaul_cherez_konja@yandex.ru"
    db_sess = db_session.create_session()
    db_sess.add(user)
    db_sess.commit()

    user = User()
    user.surname = "Павельчук"
    user.name = "Артём"
    user.age = 1000
    user.position = 'Peter_I'
    user.speciality = 'historic'
    user.address = 'Borodino'
    user.email = "Peter_I_real_krutoi_paren_not_dota_player@pushcin.mail"
    db_sess = db_session.create_session()
    db_sess.add(user)

    db_sess.commit()
    '''app.run()'''


if __name__ == '__main__':
    main()